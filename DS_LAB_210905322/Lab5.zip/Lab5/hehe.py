import numpy as np 
print(np.arange(10,30,4))